package com.snhu.sslserver;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@RestController
public class ChecksumController {

    @GetMapping("/hash")
    public String getHash() throws NoSuchAlgorithmException {
        String name = "Malachi Okongwu";
        String data = "CS305 Secure Software Project Submission";
        String input = name + ":" + data;

        // Generate SHA-256 hash
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] digest = md.digest(input.getBytes());
        StringBuilder hexString = new StringBuilder();

        for (byte b : digest) {
            hexString.append(String.format("%02x", b));
        }

        return "Name: " + name + "<br>Data: " + data + "<br>SHA-256 Checksum: " + hexString.toString();
    }
}
