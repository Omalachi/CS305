package com.snhu.sslserver;

import java.security.MessageDigest; // <-- Add this import
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class ServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(ServerApplication.class, args);
    }

}

@RestController
class ServerController {
    //FIXME:  Add hash function to return the checksum value for the data string that should contain your name.    
    @RequestMapping("/hash")
    public String myHash() {
        String data = "Malachi Okongwu"; // 👈 Your unique data string

        try {
            // Create MessageDigest instance with SHA-256
            MessageDigest md = MessageDigest.getInstance("SHA-256");

            // Generate checksum as byte array
            byte[] hash = md.digest(data.getBytes());

            // Convert byte array to hex string
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }

            return "<p>data: " + data + "</p><p>SHA-256 Checksum: " + hexString.toString() + "</p>";

        } catch (Exception e) {
            return "Error generating hash: " + e.getMessage();
        }
    }
}
